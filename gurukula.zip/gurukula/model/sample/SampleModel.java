package com.snipe.gurukula.model.sample;

import java.io.Serializable;
import java.util.Date;

public class SampleModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1065059773451498397L;

	private long sampleID;
	private String name;
	private int age;
	private String address;
	private long mobilenumber;
	private Date createdDate;
	private Date modificationDate;
	private boolean status;

	public long getSampleID() {
		return sampleID;
	}

	public void setSampleID(long sampleID) {
		this.sampleID = sampleID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	

	public long getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

}
