package com.snipe.gurukula.mapper.sample;

import org.springframework.stereotype.Component;

import com.snipe.gurukula.domain.sample.SampleDomain;
import com.snipe.gurukula.mapper.AbstractModelMapper;
import com.snipe.gurukula.model.sample.SampleModel;

@Component
public class SampleMapper extends AbstractModelMapper<SampleModel, SampleDomain> {

	@Override
	public Class<SampleModel> entityType() {
		// TODO Auto-generated method stub
		return SampleModel.class;
	}

	@Override
	public Class<SampleDomain> modelType() {
		// TODO Auto-generated method stub
		return SampleDomain.class;
	}

	
}
