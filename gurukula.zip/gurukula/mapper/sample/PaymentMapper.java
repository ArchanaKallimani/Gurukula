package com.snipe.gurukula.mapper.sample;


import org.springframework.stereotype.Component;

import com.snipe.gurukula.domain.sample.PaymentDomain;
import com.snipe.gurukula.mapper.AbstractModelMapper;
import com.snipe.gurukula.model.sample.PaymentModel;

@Component
public class PaymentMapper extends AbstractModelMapper<PaymentModel, PaymentDomain>{

	@Override
	public Class<PaymentModel> entityType() {
		// TODO Auto-generated method stub
		return PaymentModel.class;
	}

	@Override
	public Class<PaymentDomain> modelType() {
		// TODO Auto-generated method stub
		return PaymentDomain.class;
	}

}
