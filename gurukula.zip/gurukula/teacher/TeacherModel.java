package com.snipe.gurukula.teacher;

import java.io.Serializable;

public class TeacherModel implements Serializable {
	
	
	private static final long serialVersionUID = 6372681549384745961L;
	
	private long teacherId;
	private long registerId;
	private int experience;
	private String previousWorkPlace;
	private String[] langauages;
	private String subject;
	public long getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(long teacherId) {
		this.teacherId = teacherId;
	}
	public long getRegisterId() {
		return registerId;
	}
	public void setRegisterId(long registerId) {
		this.registerId = registerId;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getPreviousWorkPlace() {
		return previousWorkPlace;
	}
	public void setPreviousWorkPlace(String previousWorkPlace) {
		this.previousWorkPlace = previousWorkPlace;
	}
	public String[] getLangauages() {
		return langauages;
	}
	public void setLangauages(String[] langauages) {
		this.langauages = langauages;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
