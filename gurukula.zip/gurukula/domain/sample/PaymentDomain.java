package com.snipe.gurukula.domain.sample;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;

@Entity
@Table(name="payment")
public class PaymentDomain implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6074788627667930944L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long paymentID;

	@Column(name = "mode")
	private String mode;

	@Column(name = "amount")
	private int amount;

	@Column(name="sampleID")
	private long sampleID;
	
	@Column(name = "mobilenumber")
	private long mobilenumber;

	@Column(name = "createddate")
	@Temporal(javax.persistence.TemporalType.TIMESTAMP)
	private Date createdDate;

	@Column(name = "modificationdate")
	@Temporal(javax.persistence.TemporalType.TIMESTAMP)
	private Date modificationDate;

	@Column(name = "status")
	private boolean status;

	public long getPaymentID() {
		return paymentID;
	}

	public void setPaymentID(long paymentID) {
		this.paymentID = paymentID;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public long getSampleID() {
		return sampleID;
	}

	public void setSampleID(long sampleID) {
		this.sampleID = sampleID;
	}

	public long getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
	

}
