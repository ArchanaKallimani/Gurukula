package com.snipe.gurukula.coordinator;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EventRepository extends JpaRepository<EventDomain, Long>{

}
