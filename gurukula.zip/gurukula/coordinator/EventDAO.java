package com.snipe.gurukula.coordinator;

import java.util.List;

import com.snipe.gurukula.response.Response;

public interface EventDAO {
	
	public Response add(EventDomain eventDomain)throws Exception;
	
	public List<EventDomain> getevents()throws Exception;
	
	public EventDomain getevents(int eventId)throws Exception;
	
	public Response eventUpdate(EventDomain eventDomain)throws Exception;
	
	public Response eventDelete(int eventId)throws Exception;

}
