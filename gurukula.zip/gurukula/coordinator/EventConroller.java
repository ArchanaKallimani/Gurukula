package com.snipe.gurukula.coordinator;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.snipe.gurukula.admin.RoleModel;
import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.response.ErrorObject;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;


@RestController
@RequestMapping("/events")
public class EventConroller {
	
	private static final Logger logger = LoggerFactory.getLogger(EventConroller.class);
	
	@Autowired
	EventService eventService;
	
	@RequestMapping(value = "/eventadd", method = RequestMethod.POST, produces = "application/json")
	public Response add(@RequestBody EventModel eventModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("addevent: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("addevent: Received request: " + CommonUtils.getJson(eventModel));

		return eventService.add(eventModel);

	}
	@RequestMapping(value = "/eventlist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getevents(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("getevents: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		List<EventModel> eventModel = eventService.getevents();

		Response res = CommonUtils.getResponseObject("List of events");
		if (eventModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("eventlist Not Found", "eventlist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(eventModel);
		}
		logger.info("getevents: Sent response");
		return CommonUtils.getJson(res);
	}
	
	
	@RequestMapping(value = "/eventlist/{eventId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getevents(@PathVariable("eventId") int eventId, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.info("getevent: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));

		EventModel eventModel = eventService.getevents(eventId);

		Response res = CommonUtils.getResponseObject("Eventlist Details");
		if (eventModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("Eventlist Not Found", "Eventlist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(eventModel);
		}
		logger.info("getevents: Sent response");
		return CommonUtils.getJson(res);
	}
	 @RequestMapping(value = "/eventupdate", method = RequestMethod.PUT, produces = "application/json")
		public Response eventUpdate(@RequestBody EventModel eventModel, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			logger.info("updateEvent: Received request URL: " + request.getRequestURL().toString()
					+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
			logger.info("updateEvent: Received request: " + CommonUtils.getJson(eventModel));

			return eventService.eventUpdate(eventModel);

		}
	 
	 @RequestMapping(value = "/eventlist/{eventId}", method = RequestMethod.DELETE, produces = "application/json")
		public @ResponseBody Response eventDelete(@PathVariable("eventId") int eventId, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			logger.info("deleteEvent: Received request URL: " + request.getRequestURL().toString()
					+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
			logger.info("deleteEvent: Received request: " + CommonUtils.getJson(eventId));
			return eventService.eventDelete(eventId);
		}
		
}
