package com.snipe.gurukula.coordinator;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.snipe.gurukula.admin.RoleDomain;
import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;


@Repository
@Transactional
public class EventDAOImpl implements EventDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(EventDAOImpl.class);
	
	@Autowired
	EntityManager entityManager;
	
	public Response add(EventDomain eventDomain) {
		Response response=CommonUtils.getResponseObject("Add event Data");
		try {
			entityManager.persist(eventDomain);
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			response.setData(eventDomain);
		}catch(Exception e) {
			logger.error("Exception create In EventDAOImpl" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
			
		}
		return response;
		
	}
	
	@SuppressWarnings("unchecked")
	public List<EventDomain> getevents()throws Exception{
		try {
			String  hql = "FROM EventDomain";
			return (List<EventDomain>) entityManager.createQuery(hql).getResultList();
			
		}catch(Exception e) {
			logger.error("Exception in getevents" + e.getMessage());
		}
		return null;
	}
	
	public EventDomain getevents(int eventId) throws Exception {
		try {
			String hql = "FROM EventDomain where eventId=?1";
			return (EventDomain) entityManager.createQuery(hql).setParameter(1, eventId).getSingleResult();

		} catch (Exception e) {
			logger.error("Exception in getevents" + e.getMessage());
			return null;
		}
		
	}
	
	public Response eventUpdate(EventDomain eventDomain)throws Exception{
		
		Response response = CommonUtils.getResponseObject("Update event data");
		try {
		EventDomain eventDomain1=getevents(eventDomain.getEventId());
		eventDomain1.setEventId(eventDomain.getEventId());
		eventDomain1.setEvent(eventDomain.getEvent());
		eventDomain.setEventDate(eventDomain.getEventDate());
		eventDomain1.setCreationDate(eventDomain.getCreationDate());
		eventDomain1.setModificationDate(eventDomain.getModificationDate());
		entityManager.flush();
		response.setStatusText(StatusCode.SUCCESS.name());
		response.setStatus(StatusCode.SUCCESS.getCode());
		
		}catch(Exception ex) {
			logger.error("Exception in events" + ex.getMessage());
			return null;
		}
		
		return response;
	}
	
	public Response eventDelete(int eventId)throws Exception{
		Response response=CommonUtils.getResponseObject("delete event data");
		try {
			EventDomain eventDomain =getevents(eventId);
			entityManager.remove(eventDomain);
			entityManager.flush();
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			
			
		}catch(Exception e) {
			logger.error("Exception in eventDelete" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
			
		}
		return null;
	}

}
