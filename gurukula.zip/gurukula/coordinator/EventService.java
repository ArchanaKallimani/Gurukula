package com.snipe.gurukula.coordinator;

import java.util.List;

import com.snipe.gurukula.response.Response;

public interface EventService {
	
	public Response add(EventModel eventModel)throws Exception;
	
	public List<EventModel> getevents()throws Exception;
	
	
	public EventModel getevents(int eventId)throws Exception;
	
	public Response eventUpdate(EventModel eventModel)throws Exception;
	
	public Response eventDelete(int eventId)throws Exception;
	

}
