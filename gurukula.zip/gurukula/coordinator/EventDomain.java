package com.snipe.gurukula.coordinator;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="eventdata")
public class EventDomain implements Serializable{
	 private static final long serialVersionUID = 6472681549384745061L;
	 
	 @Id
	 private int eventId;
	 @Column(name="event")
	 private String event;
	 @Column(name="eventDate")
	 private String eventDate;
	 @Column(name="creationDate")
	 private Date creationDate;
	 @Column(name="modificationDate")
	 private Date modificationDate;
	 @Column(name="status")
	 private boolean status;
	 
	 public EventDomain()
	 {
		 
	 }

	public EventDomain(int eventId, String event, String eventDate, Date creationDate, Date modificationDate,
			boolean status) {
		super();
		this.eventId = eventId;
		this.event = event;
		this.eventDate = eventDate;
		this.creationDate = creationDate;
		this.modificationDate = modificationDate;
		this.status = status;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	 

}
