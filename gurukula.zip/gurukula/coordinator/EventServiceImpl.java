package com.snipe.gurukula.coordinator;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snipe.gurukula.admin.RoleDomain;
import com.snipe.gurukula.admin.RoleModel;
import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Service
public class EventServiceImpl implements EventService {
	private static final Logger logger = LoggerFactory.getLogger(EventServiceImpl.class);
	
	@Autowired
	EventDAO eventDAO;
	@Autowired
	EventMapper eventMapper;
	@Autowired
	EventRepository eventRepository;
	
	public Response add(EventModel eventModel)throws Exception{
		Response response = CommonUtils.getResponseObject("Event Creation");
		try {

		
			EventDomain eventDomain=new EventDomain();
			BeanUtils.copyProperties(eventModel, eventDomain);
			response = eventDAO.add(eventDomain);

		} catch (Exception e) {
			logger.error("IOException create in EventServiceImpl" + e.getMessage());
			response.setStatusText(StatusCode.ERROR.getDesc());
			response.setStatus(StatusCode.ERROR.getCode());
		}
		
		return response;
		
	}
	
	public List<EventModel> getevents()throws Exception{
		try {
			List<EventDomain> eventDomain = eventDAO.getevents();
			return eventMapper.entityList(eventDomain);
		} catch (Exception ex) {
			logger.info("Exception getevents:", ex);
		}
		return null;
		
	}
	
	public EventModel getevents(int eventId) throws Exception {
		try {
			EventModel eventModel=new EventModel();
			EventDomain eventDomain=eventDAO.getevents(eventId);
			BeanUtils.copyProperties(eventDomain, eventModel);
			return eventModel;
		}catch (Exception e) {
			logger.error("IOException in getevents" + e.getMessage());
			return null;	
		}		
	}
	
	public Response eventUpdate(EventModel eventModel) throws Exception {
		try {
			EventDomain eventDomain=new EventDomain();
			BeanUtils.copyProperties(eventModel, eventDomain);
			Response response=eventDAO.eventUpdate(eventDomain);
			return response;
		}catch (Exception e) {
			logger.error("IOException in eventUpdate" + e.getMessage());
			return null;	
		}
		
		}
public Response eventDelete(int eventId)throws Exception{
		
		try {
			return eventDAO.eventDelete(eventId);
			
		}catch(Exception e) {
			logger.error("Exception in eventDelete" + e.getMessage());
			return null;
			
		}
}
	
}
