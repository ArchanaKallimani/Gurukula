package com.snipe.gurukula.coordinator;


import org.springframework.stereotype.Component;

import com.snipe.gurukula.mapper.AbstractModelMapper;

@Component
public class EventMapper extends AbstractModelMapper<EventModel,EventDomain>{
	

	@Override
	public Class <EventModel>  entityType()
	{
		return EventModel.class;
		
	}

	@Override
	public Class <EventDomain> modelType()
	{
		return EventDomain.class;
		
	}
}
