package com.snipe.gurukula.controller.sample;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.model.sample.SampleModel;
import com.snipe.gurukula.response.ErrorObject;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.service.sample.SampleService;
import com.snipe.gurukula.utils.CommonUtils;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*")
public class SampleController {

	private static final Logger logger = LoggerFactory.getLogger(SampleController.class);

	@Autowired
	SampleService sampleService;

	@RequestMapping(value = "/sampleadd", method = RequestMethod.POST, produces = "application/json")
	public Response create(@RequestBody SampleModel sampleModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("addsample: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("addsample: Received request: " + CommonUtils.getJson(sampleModel));

		return sampleService.create(sampleModel);

	}

	@RequestMapping(value = "/samplelist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getsamplelist(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("getsamplelist: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		List<SampleModel> sampleModel = sampleService.getsamplelist();

		Response res = CommonUtils.getResponseObject("List of sample");
		if (sampleModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("samplelist Not Found", "samplelist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(sampleModel);
		}
		logger.info("getsamplelist: Sent response");
		return CommonUtils.getJson(res);
	}
	
	@RequestMapping(value = "/samplelist/{sampleID}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getsamplelist(@PathVariable("sampleID") long sampleID, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.info("getsamplelist: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));

		SampleModel sampleModel = sampleService.getsamplelist(sampleID);

		Response res = CommonUtils.getResponseObject("Samplelist Details");
		if (sampleModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("Samplelist Not Found", "Samplelist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(sampleModel);
		}
		logger.info("getsamplelist: Sent response");
		return CommonUtils.getJson(res);
	}

	@RequestMapping(value = "/updatesample", method = RequestMethod.PUT, produces = "application/json")
	public Response updateSample(@RequestBody SampleModel sampleModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("updateSample: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("updateSample: Received request: " + CommonUtils.getJson(sampleModel));

		return sampleService.updateSample(sampleModel);

	}
}
