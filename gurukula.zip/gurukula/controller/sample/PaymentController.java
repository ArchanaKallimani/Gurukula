package com.snipe.gurukula.controller.sample;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.model.sample.PaymentModel;
import com.snipe.gurukula.model.sample.SampleModel;
import com.snipe.gurukula.response.ErrorObject;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.service.sample.PaymentService;
import com.snipe.gurukula.service.sample.SampleService;
import com.snipe.gurukula.utils.CommonUtils;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*")
public class PaymentController {
	
	private static final Logger logger = LoggerFactory.getLogger(SampleController.class);

	@Autowired
	PaymentService paymentService;

	@RequestMapping(value = "/addPayment", method = RequestMethod.POST, produces = "application/json")
	public Response create(@RequestBody PaymentModel paymentModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("addPayment: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("addPayment: Received request: " + CommonUtils.getJson(paymentModel));

		return paymentService.create(paymentModel);

	}

	@RequestMapping(value = "/paymentlist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getpaymentlist(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("getpaymentlist: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		List<PaymentModel> paymentModel = paymentService.getpaymentlist();

		Response res = CommonUtils.getResponseObject("List of getpaymentlist");
		if (paymentModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("paymentlist Not Found", "paymentlist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(paymentModel);
		}
		logger.info("getpaymentlist: Sent response");
		return CommonUtils.getJson(res);
	}

}
