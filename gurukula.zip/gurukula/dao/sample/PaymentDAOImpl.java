package com.snipe.gurukula.dao.sample;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.domain.sample.PaymentDomain;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Repository
@Transactional
public class PaymentDAOImpl implements PaymentDAO {

	@PersistenceContext
	EntityManager entityManager;

	private static final Logger logger = LoggerFactory.getLogger(PaymentDAOImpl.class);

	@Override
	public Response create(PaymentDomain paymentDomain) throws Exception {
		Response response = CommonUtils.getResponseObject("Add Sample Data");
		try {
			entityManager.persist(paymentDomain);
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			response.setData(paymentDomain);

		} catch (Exception e) {
			logger.error("Exception create in PaymentDAOImpl" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
		}

		return response;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PaymentDomain> getpaymentlist() throws Exception {
		try {
			String hql = "FROM PaymentDomain";
			return (List<PaymentDomain>) entityManager.createQuery(hql).getResultList();
		} catch (Exception e) {
			logger.error("Exception in getpaymentlist" + e.getMessage());
		}
		return null;
	}

}
