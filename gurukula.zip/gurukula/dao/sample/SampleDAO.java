package com.snipe.gurukula.dao.sample;

import java.util.List;

import com.snipe.gurukula.domain.sample.SampleDomain;
import com.snipe.gurukula.response.Response;

public interface SampleDAO {

	public Response create(SampleDomain sampleDomain) throws Exception;

	public List<SampleDomain> getsamplelist() throws Exception;
	
	public SampleDomain getsamplelist(long sampleID) throws Exception;
	
	public Response updateSample(SampleDomain sampleDomain) throws Exception;

}
