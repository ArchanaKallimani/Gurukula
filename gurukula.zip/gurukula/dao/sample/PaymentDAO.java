package com.snipe.gurukula.dao.sample;

import java.util.List;

import com.snipe.gurukula.domain.sample.PaymentDomain;
import com.snipe.gurukula.response.Response;

public interface PaymentDAO {

	public Response create(PaymentDomain paymentDomain) throws Exception;

	public List<PaymentDomain> getpaymentlist() throws Exception;
	
	

}
