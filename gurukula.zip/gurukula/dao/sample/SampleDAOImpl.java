package com.snipe.gurukula.dao.sample;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.domain.sample.SampleDomain;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Repository
@Transactional
public class SampleDAOImpl implements SampleDAO {

	private static final Logger logger = LoggerFactory.getLogger(SampleDAOImpl.class);

	@Autowired
	EntityManager entityManager;

	@Override
	public Response create(SampleDomain sampleDomain) {
		Response response = CommonUtils.getResponseObject("Add Sample Data");
		try {
			entityManager.persist(sampleDomain);
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			response.setData(sampleDomain);

		} catch (Exception e) {
			logger.error("Exception create in SampleDAOImpl" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
		}

		return response;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SampleDomain> getsamplelist() throws Exception {
		try {
			String hql = "FROM SampleDomain";
			return (List<SampleDomain>) entityManager.createQuery(hql).getResultList();
		} catch (Exception e) {
			logger.error("Exception in getsamplelist" + e.getMessage());
		}
		return null;
	}

	@Override
	public SampleDomain getsamplelist(long sampleID) throws Exception {
		try {
			String hql = "FROM SampleDomain where sampleID=?1";
			return (SampleDomain) entityManager.createQuery(hql).setParameter(1, sampleID).getSingleResult();

		} catch (Exception e) {
			logger.error("Exception in getsamplelist" + e.getMessage());
			return null;
		}
		// TODO Auto-generated method stub
	}

	@Override
	public Response updateSample(SampleDomain sampleDomain) throws Exception {
		Response response = CommonUtils.getResponseObject("Update sample data");
		try {
			entityManager.flush();
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());

		} catch (Exception e) {
			logger.error("Exception in sample" + e.getMessage());
			return null;
		}
		return response;
	}

}
