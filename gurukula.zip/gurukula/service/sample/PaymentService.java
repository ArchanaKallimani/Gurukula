package com.snipe.gurukula.service.sample;

import java.util.List;

import com.snipe.gurukula.model.sample.PaymentModel;
import com.snipe.gurukula.model.sample.SampleModel;
import com.snipe.gurukula.response.Response;

public interface PaymentService {
	
	public Response create(PaymentModel paymentModel) throws Exception;

	public List<PaymentModel> getpaymentlist() throws Exception;

}
