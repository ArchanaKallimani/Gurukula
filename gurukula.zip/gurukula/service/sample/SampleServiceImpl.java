package com.snipe.gurukula.service.sample;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.dao.sample.SampleDAO;
import com.snipe.gurukula.domain.sample.SampleDomain;
import com.snipe.gurukula.mapper.sample.SampleMapper;
import com.snipe.gurukula.model.sample.SampleModel;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Service
public class SampleServiceImpl implements SampleService {

	private static final Logger logger = LoggerFactory.getLogger(SampleServiceImpl.class);

	@Autowired
	SampleDAO sampleDAO;

	@Autowired
	SampleMapper sampleMapper;

	@Override
	public Response create(SampleModel sampleModel) throws Exception {
		Response response = CommonUtils.getResponseObject("Sample Creation");
		try {

			SampleDomain sampleDomain = new SampleDomain();
			BeanUtils.copyProperties(sampleModel, sampleDomain);
			response = sampleDAO.create(sampleDomain);

		} catch (Exception e) {
			logger.error("IOException create in SampleServiceImpl" + e.getMessage());
			response.setStatusText(StatusCode.ERROR.getDesc());
			response.setStatus(StatusCode.ERROR.getCode());
		}
		// TODO Auto-generated method stub
		return response;
	}

	@Override
	public List<SampleModel> getsamplelist() throws Exception {
		try {
			List<SampleDomain> sampleDomain = sampleDAO.getsamplelist();
			return sampleMapper.entityList(sampleDomain);
		} catch (Exception ex) {
			logger.info("Exception getsamplelist:", ex);
		}
		return null;
	}

	@Override
	public SampleModel getsamplelist(long sampleID) throws Exception {
		try {
			SampleModel sampleModel= new SampleModel();
			SampleDomain sampleDomain=sampleDAO.getsamplelist(sampleID);
			BeanUtils.copyProperties(sampleDomain, sampleModel);
			return sampleModel;
		}catch (Exception e) {
			logger.error("IOException in getsamplelist" + e.getMessage());
			return null;	
		}		
	}

	@Override
	public Response updateSample(SampleModel sampleModel) throws Exception {
	try {
		SampleDomain sampleDomain=new SampleDomain();
		BeanUtils.copyProperties(sampleModel, sampleDomain);
		Response response=sampleDAO.updateSample(sampleDomain);
		return response;
	}catch (Exception e) {
		logger.error("IOException in updateSample" + e.getMessage());
		return null;	
	}
	
	}

}
