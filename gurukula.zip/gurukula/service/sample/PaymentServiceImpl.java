package com.snipe.gurukula.service.sample;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.dao.sample.PaymentDAO;
import com.snipe.gurukula.domain.sample.PaymentDomain;
import com.snipe.gurukula.mapper.sample.PaymentMapper;
import com.snipe.gurukula.model.sample.PaymentModel;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Service
public class PaymentServiceImpl implements PaymentService {

	private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);

	@Autowired
	PaymentDAO paymentDAO;

	@Autowired
	PaymentMapper paymentMapper;

	@Override
	public Response create(PaymentModel paymentModel) throws Exception {
		Response response = CommonUtils.getResponseObject("Sample Creation");
		try {

			PaymentDomain paymentDomain = new PaymentDomain();
			BeanUtils.copyProperties(paymentModel, paymentDomain);
			response = paymentDAO.create(paymentDomain);

		} catch (Exception e) {
			logger.error("IOException create in PaymentServiceImpl" + e.getMessage());
			response.setStatusText(StatusCode.ERROR.getDesc());
			response.setStatus(StatusCode.ERROR.getCode());
		}
		// TODO Auto-generated method stub
		return response;
	}

	@Override
	public List<PaymentModel> getpaymentlist() throws Exception {
		try {
			List<PaymentDomain> paymentDomain = paymentDAO.getpaymentlist();
			return paymentMapper.entityList(paymentDomain);
		} catch (Exception ex) {
			logger.info("Exception getpaymentlist:", ex);
		}
		return null;
	}

}
