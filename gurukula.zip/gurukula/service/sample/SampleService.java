package com.snipe.gurukula.service.sample;

import java.util.List;

import com.snipe.gurukula.model.sample.SampleModel;
import com.snipe.gurukula.response.Response;

public interface SampleService {

	public Response create(SampleModel sampleModel) throws Exception;

	public List<SampleModel> getsamplelist() throws Exception;
	
	public SampleModel getsamplelist(long sampleID) throws Exception;
	
	public Response updateSample(SampleModel sampleModel) throws Exception;

}
