package com.snipe.gurukula.admin;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="role")
public class RoleDomain implements Serializable {
	
	private static final long serialVersionUID = 8165975687785791568L;
	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private long roleId;
	
	@Column
	private String roleName;
	
	@Column(name="creationDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationDate;
	
	@Column(name="modificationDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modificationDate;
	
	@Column(name="status")
	private boolean status;
	
	public RoleDomain() {
		
	}
	
	
	public RoleDomain(long roleId, String roleName, Date creationDate, Date modificationDate, boolean status) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		this.creationDate = creationDate;
		this.modificationDate = modificationDate;
		this.status = status;
	}


	public long getRoleId() {
		return roleId;
	}
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getModificationDate() {
		return modificationDate;
	}
	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
