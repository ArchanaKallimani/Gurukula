package com.snipe.gurukula.admin;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.domain.sample.SampleDomain;
import com.snipe.gurukula.model.sample.SampleModel;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Service
public class RoleServiceImpl implements RoleService {
	
	
	private static final Logger logger = LoggerFactory.getLogger(RoleServiceImpl.class);
	
	@Autowired
	RoleDAO roleDAO;
	
	@Autowired
	RoleMapper roleMapper;
	
	@Autowired
	RoleRepository roleRepository;
	
	@Override
	public Response create(RoleModel roleModel) throws Exception {
		Response response = CommonUtils.getResponseObject("Role Creation");
		try {

		
			RoleDomain roleDomain=new RoleDomain();
			BeanUtils.copyProperties(roleModel, roleDomain);
			response = roleDAO.create(roleDomain);

		} catch (Exception e) {
			logger.error("IOException create in RoleServiceImpl" + e.getMessage());
			response.setStatusText(StatusCode.ERROR.getDesc());
			response.setStatus(StatusCode.ERROR.getCode());
		}
		
		return response;
	}
	
	@Override
	public List<RoleModel> getrolelist() throws Exception {
		try {
			List<RoleDomain> roleDomain = roleDAO.getrolelist();
			return roleMapper.entityList(roleDomain);
		} catch (Exception ex) {
			logger.info("Exception getrolelist:", ex);
		}
		return null;
	}
	
	@Override
	public RoleModel getrolelist(long roleId) throws Exception {
		try {
			RoleModel roleModel=new RoleModel();
			RoleDomain roleDomain=roleDAO.getrolelist(roleId);
			BeanUtils.copyProperties(roleDomain, roleModel);
			return roleModel;
		}catch (Exception e) {
			logger.error("IOException in getrolelist" + e.getMessage());
			return null;	
		}		
	}
	
	@Override
	public Response deleteRole(long roleId)throws Exception{
		
		try {
			return roleDAO.deleteRole(roleId);
			
		}catch(Exception e) {
			logger.error("Exception in deleteRole" + e.getMessage());
			return null;
			
		}
		
	}
	@Override
	public Response updateRole(RoleModel roleModel) throws Exception {
		try {
			RoleDomain roleDomain=new RoleDomain();
			BeanUtils.copyProperties(roleModel, roleDomain);
			Response response=roleDAO.updateRole(roleDomain);
			return response;
		}catch (Exception e) {
			logger.error("IOException in updateRole" + e.getMessage());
			return null;	
		}
		
		}
	

}
