package com.snipe.gurukula.admin;

import java.util.List;

import com.snipe.gurukula.response.Response;

public interface RoleService {
	
	public Response create(RoleModel roleModel) throws Exception;

	public List<RoleModel> getrolelist() throws Exception;
	
	public RoleModel getrolelist(long roleId) throws Exception;
	
	public Response deleteRole(long roleId)throws Exception;
	
	public Response updateRole(RoleModel roleModel)throws Exception;

}
