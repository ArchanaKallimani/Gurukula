package com.snipe.gurukula.admin;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<RoleDomain,Long>{

}
