package com.snipe.gurukula.admin;
import com.snipe.gurukula.mapper.AbstractModelMapper;

import org.springframework.stereotype.Component;

@Component
public class RoleMapper extends AbstractModelMapper<RoleModel,RoleDomain> {
	
	

	@Override
	public Class <RoleModel>  entityType()
	{
		return RoleModel.class;
		
	}
	
	@Override
	public Class <RoleDomain>  modelType()
	{
		return RoleDomain.class;
		
	}

	
	
	
	

}
