package com.snipe.gurukula.admin.registration.dropdown;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="country")
public class CountryDomain implements Serializable{
	
	private static final long serialVersionUID = 6373681549384745067L;
	
	@Id
	private int id;
	@Column(name="sortname")
	private String sortname;
	@Column(name="name")
	private String name;
	@Column(name="phonecode")
	private int phonecode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSortname() {
		return sortname;
	}
	public void setSortname(String sortname) {
		this.sortname = sortname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhonecode() {
		return phonecode;
	}
	public void setPhonecode(int phonecode) {
		this.phonecode = phonecode;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	

}
