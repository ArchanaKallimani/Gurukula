package com.snipe.gurukula.admin.registration.dropdown;

public class DistDomain {

}
