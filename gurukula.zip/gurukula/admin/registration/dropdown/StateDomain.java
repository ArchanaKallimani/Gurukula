package com.snipe.gurukula.admin.registration.dropdown;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="state")
public class StateDomain implements Serializable{
	
	private static final long serialVersionUID = 6372691549384755067L;
	@Id
	private int stateId;
	
	@Column(name="stateName")
	private String stateName;
	
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
