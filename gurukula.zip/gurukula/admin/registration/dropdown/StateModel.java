package com.snipe.gurukula.admin.registration.dropdown;

import java.io.Serializable;

public class StateModel implements Serializable{
	
	private static final long serialVersionUID = 6472681549384755067L;
	
	private int stateId;
	private String stateName;
	public int getStateId() {
		return stateId;
	}
	public void setStateId(int stateId) {
		this.stateId = stateId;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
