package com.snipe.gurukula.admin.registration;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="register")
public class RegisterDomain implements Serializable {
	
	private static final long serialVersionUID = 8165975687785791569L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long registerId;
	@Column(name="firstName")
	private String firstName;
	@Column(name="lastName")
	private String lastName;
	@Column(name="gender")
	private String gender;
	@Column(name="email")
	private String email;
	@Column(name="password")
	private String password;
	@Column(name="mobileNo")
    private String mobileNo;
	@Column(name="address")
    private String address;
	@Column(name="city")
    private String city;
	@Column(name="pin")
    private int pin;
	@Column(name="state")
    private String state;
	@Column(name="roleId")
    private long roleId;
    @Column(name="creationDate")
	@Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name="modificationDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modificationDate;
    @Column(name="status")
	private boolean status;
    
    public RegisterDomain() {
    	
    }
    

	public RegisterDomain(long registerId, String firstName, String lastName, String gender, String email,
			String password, String mobileNo, String address, String city, int pin, String state, long roleId,
			Date creationDate, Date modificationDate, boolean status) {
		super();
		this.registerId = registerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.email = email;
		this.password = password;
		this.mobileNo = mobileNo;
		this.address = address;
		this.city = city;
		this.pin = pin;
		this.state = state;
		this.roleId = roleId;
		this.creationDate = creationDate;
		this.modificationDate = modificationDate;
		this.status = status;
	}


	public long getRegisterId() {
		return registerId;
	}

	public void setRegisterId(long registerId) {
		this.registerId = registerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModificationDate() {
		return modificationDate;
	}

	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    

}
