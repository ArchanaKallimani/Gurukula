package com.snipe.gurukula.admin.registration;

import java.util.List;

import com.snipe.gurukula.response.Response;

public interface RegisterDAO {
	
	public Response add(RegisterDomain registerDomain)throws Exception;
	
	public List<RegisterDomain> getregisterlist()throws Exception;
	
	public RegisterDomain getregisterlist(long registerId)throws Exception;
	
	public Response updateRegistration(RegisterDomain registerDomain)throws Exception;
	
	public Response deleteRegister(long registerId)throws Exception;

}
