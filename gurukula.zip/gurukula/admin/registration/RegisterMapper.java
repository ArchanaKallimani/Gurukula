package com.snipe.gurukula.admin.registration;

import org.springframework.stereotype.Component;

import com.snipe.gurukula.mapper.AbstractModelMapper;

@Component
public class RegisterMapper extends AbstractModelMapper<RegisterModel,RegisterDomain>{
	
	@Override
	public Class <RegisterModel>  entityType()
	{
		return RegisterModel.class;
		
	}
	
	@Override
	public Class <RegisterDomain>  modelType()
	{
		return RegisterDomain.class;
		
	}


}
