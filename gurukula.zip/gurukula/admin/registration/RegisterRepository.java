package com.snipe.gurukula.admin.registration;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RegisterRepository  extends JpaRepository<RegisterDomain, Long>{

}
