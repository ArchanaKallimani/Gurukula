package com.snipe.gurukula.admin.registration;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.snipe.gurukula.admin.RoleDomain;
import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Repository
@Transactional
public class RegisterDAOImpl implements RegisterDAO{
	
	public static final  Logger logger = LoggerFactory.getLogger(RegisterDAOImpl.class);
	
	@Autowired
	EntityManager entityManager;
	
	@Override
	public Response add(RegisterDomain registerDomain) {
		Response response=CommonUtils.getResponseObject("Add Registration Data");
		try {
			entityManager.persist(registerDomain);
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			response.setData(registerDomain);
		}catch(Exception e) {
			logger.error("Exception create In RegisterDAOImpl" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
			
		}
		return response;
		
	}
	@Override
	public List<RegisterDomain> getregisterlist()throws Exception{
		try {
			String hql="FROM RegisterDomain";
			return(List<RegisterDomain>)entityManager.createQuery(hql).getResultList();
			
		}catch(Exception e) {
			logger.error("Exception in getregisterlist" + e.getMessage());
			
		}
		return null;
	}
	
	@Override
	public RegisterDomain getregisterlist(long registerId) throws Exception {
		try {
			String hql = "FROM RegisterDomain where registerId=?1";
			return (RegisterDomain) entityManager.createQuery(hql).setParameter(1, registerId).getSingleResult();

		} catch (Exception e) {
			logger.error("Exception in getregisterlist" + e.getMessage());
			return null;
		}
		
	}
	
	@Override
	public Response updateRegistration(RegisterDomain registerDomain) throws Exception {
		Response response = CommonUtils.getResponseObject("Update register data");
		try {
			
			RegisterDomain registerDomain1=getregisterlist(registerDomain.getRegisterId());
			registerDomain1.setRegisterId(registerDomain.getRegisterId());
			registerDomain1.setFirstName(registerDomain.getFirstName());
			registerDomain1.setLastName(registerDomain.getLastName());
			registerDomain1.setGender(registerDomain.getGender());
			registerDomain1.setEmail(registerDomain.getEmail());
			registerDomain1.setMobileNo(registerDomain.getMobileNo());
			registerDomain1.setPassword(registerDomain.getPassword());
			registerDomain1.setAddress(registerDomain.getAddress());
			registerDomain1.setPin(registerDomain.getPin());
			registerDomain1.setState(registerDomain.getState());
			registerDomain1.setRoleId(registerDomain.getRoleId());
			registerDomain1.setCreationDate(registerDomain.getCreationDate());
			registerDomain1.setModificationDate(registerDomain.getModificationDate());
			
			
		
			entityManager.flush();
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());

		} catch (Exception e) {
			logger.error("Exception in register" + e.getMessage());
			return null;
		}
		return response;
	}
	
	@Override
	public Response deleteRegister(long registerId)throws Exception{
		Response response=CommonUtils.getResponseObject("delete register data");
		try {
			RegisterDomain registerDomain =getregisterlist(registerId);
			entityManager.remove(registerDomain);
			entityManager.flush();
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			
			
		}catch(Exception e) {
			logger.error("Exception in deleteRegister" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
			
		}
		return null;
	}

}
