package com.snipe.gurukula.admin.registration;

import java.util.List;

import com.snipe.gurukula.response.Response;

public interface RegisterService {
	
	
	public Response add(RegisterModel registerModel)throws Exception;
	
	public List<RegisterModel> getregisterlist()throws Exception;
	
	public RegisterModel getregisterlist(long registerId)throws Exception;

	public Response updateRegistration(RegisterModel registerModel)throws Exception;
	
	public Response deleteRegister(long registerId)throws Exception;
}
