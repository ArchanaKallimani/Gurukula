package com.snipe.gurukula.admin.registration;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.snipe.gurukula.admin.RoleModel;
import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.controller.sample.SampleController;
import com.snipe.gurukula.response.ErrorObject;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@RestController
@RequestMapping("/register")
public class RegisterController {
	
	private static final Logger logger = LoggerFactory.getLogger(RegisterController.class);
	
	@Autowired
	RegisterService registerService;
	
	@RequestMapping(value = "/registeradd", method = RequestMethod.POST, produces = "application/json")
	public Response add(@RequestBody RegisterModel registerModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("addregister: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("addregister: Received request: " + CommonUtils.getJson(registerModel));

		return registerService.add(registerModel);

	}
	
	@RequestMapping(value = "/registerlist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getregisterlist(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("getregisterlist: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		List<RegisterModel> registerModel = registerService.getregisterlist();

		Response res = CommonUtils.getResponseObject("List of register");
		if (registerModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("registerlist Not Found", "registerlist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(registerModel);
		}
		logger.info("getregisterlist: Sent response");
		return CommonUtils.getJson(res);
	}
	@RequestMapping(value = "/registerlist/{registerId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getregisterlist(@PathVariable("registerId") long registerId, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.info("getregisterlist: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));

		RegisterModel registerModel = registerService.getregisterlist(registerId);

		Response res = CommonUtils.getResponseObject("Registerlist Details");
		if (registerModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("Registerlist Not Found", "Registerlist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(registerModel);
		}
		logger.info("getregisterlist: Sent response");
		return CommonUtils.getJson(res);
	}
	
	@RequestMapping(value = "/updateregister", method = RequestMethod.PUT, produces = "application/json")
	public Response updateRegistration(@RequestBody RegisterModel registerModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("updateRegistration: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("updateRegistration: Received request: " + CommonUtils.getJson(registerModel));

		return registerService.updateRegistration(registerModel);

	}
	
	 @RequestMapping(value = "/registerlist/{registerId}", method = RequestMethod.DELETE, produces = "application/json")
		public @ResponseBody Response deleteRegister(@PathVariable("registerId") long registerId, HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			logger.info("deleteRegister: Received request URL: " + request.getRequestURL().toString()
					+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
			logger.info("deleteRegister: Received request: " + CommonUtils.getJson(registerId));
			return registerService.deleteRegister(registerId);
		}

}
