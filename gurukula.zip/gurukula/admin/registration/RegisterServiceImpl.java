package com.snipe.gurukula.admin.registration;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.snipe.gurukula.admin.RoleDomain;
import com.snipe.gurukula.admin.RoleModel;
import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Service
public class RegisterServiceImpl implements RegisterService{
	private static final Logger logger = LoggerFactory.getLogger(RegisterServiceImpl.class);

	@Autowired
	RegisterDAO registerDAO;
	
	@Autowired
	RegisterMapper registerMapper;
	
	@Autowired
	RegisterRepository registerRepository;

	@Override
	public Response add(RegisterModel registerModel) throws Exception {
		Response response = CommonUtils.getResponseObject("Registration Creation");
		try {

			RegisterDomain registerDomain = new RegisterDomain();
			BeanUtils.copyProperties(registerModel, registerDomain);
			response = registerDAO.add(registerDomain);

		} catch (Exception e) {
			logger.error("IOException add in RegisterServiceImpl" + e.getMessage());
			response.setStatusText(StatusCode.ERROR.getDesc());
			response.setStatus(StatusCode.ERROR.getCode());
		}

		return response;
	}
	@Override
	public List<RegisterModel> getregisterlist() throws Exception {
		try {
			List<RegisterDomain> registerDomain = registerDAO.getregisterlist();
			return registerMapper.entityList(registerDomain);
		} catch (Exception ex) {
			logger.info("Exception getregisterlist:", ex);
		}
		return null;
	}
	
	@Override
	public RegisterModel getregisterlist(long registerId) throws Exception {
		try {
			RegisterModel registerModel=new RegisterModel();
			RegisterDomain registerDomain=registerDAO.getregisterlist(registerId);
			BeanUtils.copyProperties(registerDomain, registerModel);
			return registerModel;
		}catch (Exception e) {
			logger.error("IOException in getregisterlist" + e.getMessage());
			return null;	
		}		
	}
	@Override
	public Response updateRegistration(RegisterModel registerModel) throws Exception {
		try {
			RegisterDomain registerDomain=new RegisterDomain();
			BeanUtils.copyProperties(registerModel, registerDomain);
			Response response=registerDAO.updateRegistration(registerDomain);
			return response;
		}catch (Exception e) {
			logger.error("IOException in updateRegistration" + e.getMessage());
			return null;	
		}
		
		}
	
	@Override
public Response deleteRegister(long registerId)throws Exception{
		
		try {
			return registerDAO.deleteRegister(registerId);
			
		}catch(Exception e) {
			logger.error("Exception in deleteRegister" + e.getMessage());
			return null;
			
		}
		
	}

}
