package com.snipe.gurukula.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.model.sample.SampleModel;
import com.snipe.gurukula.response.ErrorObject;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@RestController
@RequestMapping("/role1")
public class RoleController {
	
	private static final Logger logger = LoggerFactory.getLogger(RoleController.class);
	
	@Autowired
	RoleService roleService;
	/*private static Map<String ,RoleModel>RoleRepo=new HashMap();
	
	static {
		RoleModel admin=new RoleModel();
		admin.setRoleId(1);
		admin.setRoleName("Admin");
		
		RoleModel teacher=new RoleModel();
		teacher.setRoleId(2);
		teacher.setRoleName("Teacher");
		
		RoleModel staff=new RoleModel();
		staff.setRoleId(3);
		staff.setRoleName("Staff");
		
		RoleModel cordinator=new RoleModel();
		cordinator.setRoleId(4);
		cordinator.setRoleName("Co-Ordinator");
		
	}*/
	
	@RequestMapping(value = "/roleadd", method = RequestMethod.POST, produces = "application/json")
	public Response create(@RequestBody RoleModel roleModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("addrole: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("addrole: Received request: " + CommonUtils.getJson(roleModel));

		return roleService.create(roleModel);

	}
	
	@RequestMapping(value = "/rolelist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getrolelist(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		logger.info("getrolelist: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		List<RoleModel> roleModel = roleService.getrolelist();

		Response res = CommonUtils.getResponseObject("List of role");
		if (roleModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("rolelist Not Found", "rolelist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(roleModel);
		}
		logger.info("getrolelist: Sent response");
		return CommonUtils.getJson(res);
	}
	
	@RequestMapping(value = "/rolelist/{roleId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getrolelist(@PathVariable("roleId") long roleId, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		logger.info("getrolelist: Received request: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));

		RoleModel roleModel = roleService.getrolelist(roleId);

		Response res = CommonUtils.getResponseObject("Rolelist Details");
		if (roleModel == null) {
			ErrorObject err = CommonUtils.getErrorResponse("Rolelist Not Found", "Rolelist Not Found");
			res.setError(err);
			res.setStatus(StatusCode.ERROR.getCode());
			res.setStatusText(StatusCode.ERROR.getDesc());
		} else {
			res.setData(roleModel);
		}
		logger.info("getrolelist: Sent response");
		return CommonUtils.getJson(res);
	}

 @RequestMapping(value = "/rolelist/{roleId}", method = RequestMethod.DELETE, produces = "application/json")
	public @ResponseBody Response deleteRole(@PathVariable("roleId") long roleId, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("deleteRole: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("deleteRole: Received request: " + CommonUtils.getJson(roleId));
		return roleService.deleteRole(roleId);
	}
	
 @RequestMapping(value = "/updaterole", method = RequestMethod.PUT, produces = "application/json")
	public Response updateRole(@RequestBody RoleModel roleModel, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		logger.info("updateRole: Received request URL: " + request.getRequestURL().toString()
				+ ((request.getQueryString() == null) ? "" : "?" + request.getQueryString().toString()));
		logger.info("updateRole: Received request: " + CommonUtils.getJson(roleModel));

		return roleService.updateRole(roleModel);

	}
	

}
