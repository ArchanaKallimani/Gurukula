package com.snipe.gurukula.admin;

import java.io.Serializable;
import java.util.Date;

public class RoleModel implements Serializable{
	
	private static final long serialVersionUID = 6372681549384745061L;
	
	private long roleId;
	private String roleName;
	private Date creationDate;
	private Date modificationDate;
	private boolean status;
	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public long getRoleId() {
		return roleId;
	}
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getModificationDate() {
		return modificationDate;
	}
	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	
	
	
	

}
