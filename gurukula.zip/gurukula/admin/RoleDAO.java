package com.snipe.gurukula.admin;

import java.util.List;

import com.snipe.gurukula.response.Response;

public interface RoleDAO {

	
	public Response create(RoleDomain roleDomain)throws Exception;
	
	public List<RoleDomain> getrolelist() throws Exception;
	
	public RoleDomain getrolelist(long roleId) throws Exception;
	
	public Response updateRole(RoleDomain roleDomain)throws Exception;
	
	public Response deleteRole(long roleId)throws Exception;
	 
}
