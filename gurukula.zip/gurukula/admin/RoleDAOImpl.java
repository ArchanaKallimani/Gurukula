package com.snipe.gurukula.admin;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.snipe.gurukula.constant.StatusCode;
import com.snipe.gurukula.dao.sample.SampleDAOImpl;
import com.snipe.gurukula.domain.sample.SampleDomain;
import com.snipe.gurukula.response.Response;
import com.snipe.gurukula.utils.CommonUtils;

@Repository
@Transactional
public class RoleDAOImpl implements RoleDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(RoleDAOImpl.class);
	
	@Autowired
	EntityManager entityManager;

	@Override
	public Response create(RoleDomain roleDomain) {
		
		Response response=CommonUtils.getResponseObject("Add Role Data");
		try {
			entityManager.persist(roleDomain);
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			response.setData(roleDomain);
		}catch(Exception e) {
			logger.error("Exception create In RoleDAOImpl" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
			
		}
		return response;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<RoleDomain> getrolelist() throws Exception {
		try {
			String hql = "FROM RoleDomain";
			return (List<RoleDomain>) entityManager.createQuery(hql).getResultList();
		} catch (Exception e) {
			logger.error("Exception in getrolelist" + e.getMessage());
		}
		return null;
	}

	@Override
	public RoleDomain getrolelist(long roleId) throws Exception {
		try {
			String hql = "FROM RoleDomain where roleId=?1";
			return (RoleDomain) entityManager.createQuery(hql).setParameter(1, roleId).getSingleResult();

		} catch (Exception e) {
			logger.error("Exception in getrolelist" + e.getMessage());
			return null;
		}
		
	}
	
	@Override
	public Response deleteRole(long roleId)throws Exception{
		Response response=CommonUtils.getResponseObject("delete role data");
		try {
			RoleDomain roleDomain =getrolelist(roleId);
			entityManager.remove(roleDomain);
			entityManager.flush();
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());
			
			
		}catch(Exception e) {
			logger.error("Exception in deleteRole" + e.getMessage());
			response.setStatus(StatusCode.ERROR.getCode());
			response.setStatusText(StatusCode.ERROR.getDesc());
			
		}
		return null;
	}
	
	@Override
	public Response updateRole(RoleDomain roleDomain) throws Exception {
		Response response = CommonUtils.getResponseObject("Update role data");
		try {
			
			RoleDomain roleDomain1=getrolelist(roleDomain.getRoleId());
			roleDomain1.setRoleId(roleDomain.getRoleId());
			roleDomain1.setRoleName(roleDomain.getRoleName());
			roleDomain1.setCreationDate(roleDomain.getCreationDate());
			roleDomain1.setModificationDate(roleDomain.getModificationDate());
		
			entityManager.flush();
			response.setStatusText(StatusCode.SUCCESS.name());
			response.setStatus(StatusCode.SUCCESS.getCode());

		} catch (Exception e) {
			logger.error("Exception in role" + e.getMessage());
			return null;
		}
		return response;
	}
	
	
}
